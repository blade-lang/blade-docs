#ifndef STRSEP_H
#define STRSEP_H

char *strsep(char **stringp, const char *delim);

#endif /* ifndef STRSEP_H */
